// #include<iostream> 
// #include<math.h> 
// #include<cstring> 

// using namespace std; 
// char exor(char a, char b){
//     if(a==b){
//         return '0';
//     }
//     else
//     return '1';
// }

// void crc(char msg[], char pattern []){
//     int msglen=strlen(msg);
//     int plen=strlen(pattern);
//     for(int i=0;i<plen-1;i++){
// msg[msglen+i]='0';
// //  appending zeroes at the end 
//     }
//     msg[msglen+plen-1]='\0';
//     int codelen=msglen+plen-1;
//     //  length of appended msg with zeroes correspoding to the plen 
//     char temp[20], rem[20];

//     for(int i=0;i<plen;i++){
//         rem[i]=msg[i];
//     }
//     for(int j=plen;j<=codelen;j++){
//         for(int i=0;i<plen;i++){
//             temp[i]=rem[i];
//         }
//         if(rem[0]=='0'){
//             for(int i=0;i<plen-1;i++){
//                 rem[i]=temp[i+1];
//             }
//             }
//             else{
//                 for(int i=0;i<plen-1;i++){
//                     rem[i]=exor(temp[i+1], pattern[i+1]);
//                 }
//         }
//         if(j!=codelen)
//         rem[plen-1]=msg[j];
//         else 
//         rem[plen-1]='\0';
//     }
//     for(int i=0;i<plen-1;i++){
//         msg[msglen+i]=rem[i];
//     }
//     msg[codelen]='\0';
//     cout<<"checksum= "<<rem<<"\nDataword= "<<msg;
    
//     // return msg[];
// }
// int main(){
// char msg[20], pattern[20], rec[20];
// cout<<"enter the message being transmitted: ";
// cin>>msg;
// cout<<"enter the pattern value: ";
// cin>>pattern;
// crc(msg, pattern);
// cout<<"\nenter received data: ";
// cin>>rec;
// // for(int i=0;i<strlen(rec);i++){
// //     if(rec[i]==msg[i]){
// //         cout<<"no errors detected"<<endl;
// //     }
// //     else{
// //         cout<<"errors detected "<<endl;
// //     }
// // }
// crc(rec, pattern);
// // if(rem==0){
// //     cout<<"no errors detected ";
// // }
// // else{
// //     cout<<"errors detected ";
// // }
// return 0;
// }

#include <iostream>
#include <bits/stdc++.h>
using namespace std;

string CalculateCrc(const string &data, const string &generator)
{
  string dividend = data;
  int generator_length = generator.length();
  dividend.append(generator_length - 1, '0');

  for (int i = 0; i < data.length(); ++i){
    if (dividend[i] == '0'){
      continue;
    }
    for (int j = 0; j < generator_length; ++j){
      dividend[i + j] = dividend[i + j] == generator[j] ? '0' : '1';
    }
  }
  return dividend.substr(data.length());
}

int main()
{
  int data_length, generator_length;
  string data, generator;
  cout << "Enter the number of bits in input data: ";
  cin >> data_length;
  cout << "Enter the number of bits in the polynomial generator (divisor): ";
  cin >> generator_length;
  cout << "Enter the data: ";
  cin >> data;
  cout << "Enter the divisor: ";
  cin >> generator;
  string crc = CalculateCrc(data, generator);
  cout << "CRC value: " << crc << endl;
  string transmitted_data = data + crc;
  cout << "Transmitted data: " << transmitted_data << endl;
  string received_data;
  cout << "Enter the received data: ";
  cin >> received_data;
  string received_crc = CalculateCrc(received_data.substr(0, data_length), generator);
  if (received_crc == received_data.substr(data_length))
  {
    cout << "No errors detected" << endl;
  }
  else 
  {
    cout << "Errors detected" << endl;
  }
  return 0;
} 