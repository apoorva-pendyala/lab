// #include<bits/stdc++.h>

// #include<ctime>

// #define ll long long int
// using namespace std;

// void transmit(ll & i, ll & N, ll & tf, ll & tt) {
//   while (i <= tf) {
//     int z = 0;
//     for (int k = i; k < i + N && k <= tf; k++) {
//       cout << "Sending Frame No: " << k << endl;
//       tt++;
//     }
//     for (int k = i; k < i + N && k <= tf; k++) {
//       int f = rand() % 2;
//       if (!f) {
//         cout << "Acknowledgment for Frame " << k << endl;
//         z++;
//       } else {
//         cout << "Timed-out Frame Number : " << k << " has not been Received" << endl;
//         cout << "Retransmitting the whole Window" << endl;
//         // go back n arq 
//         // here the whole window is retransmitted in case there is an error during the transmission of atleast one frame in the window
//         break;
//       }
//     }
//     cout << "\n";
//     i = i + z;
//   }
// }

// int main() {
//   ll totalfr, W, tt = 0;
//   srand(time(NULL));
//   cout << "Enter total number of frames: ";
//   cin >> totalfr;
//   cout << "Enter the Window Size: ";
//   cin >> W;
//   ll i = 1;
//   transmit(i, W, totalfr, tt);
//   cout << "Total number of frames which were sent and resent are: " << tt <<endl;
//   return 0;
// }


#include <stdio.h>
#include <unistd.h>
#include <time.h>

const int WINDOW_SIZE = 2;

int main()
{
    int numFrames;
    printf("Enter the number of frames to be transmitted: ");
    scanf("%d", &numFrames);

    int base = 1, nextSeqNum = 1;

    while (base <= numFrames) {
        
        for (int i = base; i < (base + WINDOW_SIZE < numFrames + 1 ? base + WINDOW_SIZE : numFrames + 1); i++) {
            printf("Frame_No\tData\tWaiting_Time (Sec)\tAcknowledgement\tResend\n");
            printf("%d\t\t%d\t", i, (i * 17) % 100);
            
            int ackReceived = 0;
            for (int j = 1; j <= 3; j++) {
                printf("%d, ", j);
                sleep(1);
                if (j == 2 && i == 1) { 
                    printf("\t\t\tNo\t\t\tYes\n");
                    break;
                }
                if (j == 3) {
                    ackReceived = 1;
                }
            }

            // Output result
            if (ackReceived) {
                printf("\t\t\tYes\t\t\tNo\n");
                nextSeqNum++;
            }
        }
        int allAcksReceived = 1;
        for (int i = base; i < (base + WINDOW_SIZE < numFrames + 1 ? base + WINDOW_SIZE : numFrames + 1); i++) {
            if (i < nextSeqNum) continue; 
            printf("Frame_No\tData\tWaiting_Time (Sec)\tAcknowledgement\tResend\n");
            printf("%d\t\t%d\t", i, (i * 17) % 100);
            int ackReceived = 0;
            for (int j = 1; j <= 3; j++) {
                printf("%d, ", j);
                sleep(1);
                if (j == 2 && i == 1) { 
                    printf("\t\t\tNo\t\t\tYes\n");
                    allAcksReceived = 0;
                    break;
                }
                if (j == 3) {
                    ackReceived = 1;
                }
            }

            if (ackReceived) {
                printf("\t\t\tYes\t\t\tNo\n");
                nextSeqNum++;
            } else {
                allAcksReceived = 0;
            }
        }
        if (allAcksReceived) {
            base += WINDOW_SIZE;
        }
    }

    printf("All the data packets are transmitted\n");
    return 0;
}
