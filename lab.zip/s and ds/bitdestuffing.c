#include<stdio.h> 
#include<string.h>
void bitDestuffing(int n, int arr[])
{
    int brr[n];
    int i, j, k;
    i = 0;
    j = 0;
    int count = 1;
    while (i < n) {
        if (arr[i] == 1) {
            brr[j] = arr[i];
            for (k = i + 1;
                 arr[k] == 1
                 && k < n
                 && count < 5;
                 k++) {
                j++;
                brr[j] = arr[k];
                count++;
                if (count == 5) {
                    k++;
                }
                i = k;
            }
        }
 
        else {
            brr[j] = arr[i];
        }
        i++;
        j++;
    }
    for (i = 0; i < j; i++)
        printf("%d", brr[i]);
}
 
// Driver Code
int main()
{
    int n;
    printf("enter the frame size used: ");
    scanf("%d", &n);
    int arr[n];
    printf("entered the stuffed array: ");
    for(int i=0; i<n; i++){
        scanf("%d", &arr[i]);
    }
    bitDestuffing(n, arr);
 
    return 0;
}