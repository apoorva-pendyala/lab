#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#define MAX_NODES 100
int n; // number of nodes in the network
int cost[MAX_NODES][MAX_NODES]; // cost matrix for the network
int distance[MAX_NODES]; // shortest distance from source node to each node
int visited[MAX_NODES]; // array to keep track of visited nodes
int via[MAX_NODES]; // array to keep track of the intermediate nodes on the shortest path
void dijkstra(int source) {
    for (int i = 0; i < n; i++) {
        distance[i] = INT_MAX;
        visited[i] = 0;
        via[i] = -1;
    }
    distance[source] = 0;    // find shortest path from source to all other nodes
    for (int i = 0; i < n; i++) {
        // find node with minimum distance
        int min_distance = INT_MAX;
        int min_index = -1;
        for (int j = 0; j < n; j++) {
            if (!visited[j] && distance[j] < min_distance) {
                min_distance = distance[j];
                min_index = j;}}
        if (min_index == -1) {
            break;
        }
        visited[min_index] = 1;
        for (int j = 0; j < n; j++) {
            if (cost[min_index][j] != INT_MAX && distance[min_index] + cost[min_index][j] < distance[j]) {
                distance[j] = distance[min_index] + cost[min_index][j];
                via[j] = min_index;}}}}
void print_path(int node) {
    if (via[node] == -1) {
        printf("node %d: cost=%d\n", node, distance[node]);
    } else {
        print_path(via[node]);
        printf("node %d: via %d, cost=%d\n", node, via[node], distance[node]);
    }
}
int main() {
    // read input
    printf("Enter the number of nodes in the network: ");
    scanf("%d", &n);
    printf("Enter the cost matrix for the network:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &cost[i][j]);
            if (cost[i][j] == -1) {
                cost[i][j] = INT_MAX; }}}
    for (int i = 0; i < n; i++) {
        printf("Shortest paths from node %d:\n", i);
        dijkstra(i);
        for (int j = 0; j < n; j++) {
            if (j != i) {
                print_path(j);}}
        printf("\n");
    }return 0;
}