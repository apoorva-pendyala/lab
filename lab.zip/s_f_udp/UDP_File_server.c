#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#define PORT 8080
#define BUFFER_SIZE 1024

int main() {
    int server_socket;
    struct sockaddr_in server_address, client_address;
    socklen_t client_length;
    char buffer[BUFFER_SIZE];
    FILE *file;

    // Create socket
    if ((server_socket = socket(AF_INET, SOCK_DGRAM, 0)) == 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(PORT);

    // Bind the socket to localhost:8080
    if (bind(server_socket, (struct sockaddr *)&server_address, sizeof(server_address)) < 0) {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    printf("File server is running on port %d\n", PORT);

    while (1) {
        memset(buffer, 0, sizeof(buffer));
        client_length = sizeof(client_address);

        // Receive file name from client
        if (recvfrom(server_socket, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&client_address, &client_length) < 0) {
            perror("recvfrom failed");
            exit(EXIT_FAILURE);
        }

        printf("Request for file: %s\n", buffer);

        // Open the file
        file = fopen(buffer, "rb");
        if (file == NULL) {
            printf("File not found\n");
            strcpy(buffer, "File not found");
            sendto(server_socket, buffer, strlen(buffer), 0, (struct sockaddr *)&client_address, client_length);
            continue;
        }

        // Read and send file contents to client
        while (1) {
            memset(buffer, 0, sizeof(buffer));
            int bytes_read = fread(buffer, 1, BUFFER_SIZE, file);
            if (bytes_read > 0) {
                sendto(server_socket, buffer, bytes_read, 0, (struct sockaddr *)&client_address, client_length);
            } else {
                break;
            }
        }

        fclose(file);

        printf("File sent\n");
    }

    return 0;
}
